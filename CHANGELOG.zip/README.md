# Onyx-ArtificerPlus

- holding attack is now the same speed as spamming it
- gave Artificer a weak hover when Jump is held
- decreased tectonic surge cooldown and increased surge distance
- localised sun now has different speed depending on if the special button is held
- fix nanospear firing when pulsing it while having another charge

## Special Thanks To
* Miguelito for the original ArtificerImprovements mod and helping a ton with problems and code cleanup
* The Return Of Modding Discord

## Contact
For questions or bug reports, you can find us in the [RoRR Modding Server](https://discord.gg/VjS57cszMq) @Onyx
