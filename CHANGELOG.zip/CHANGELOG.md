## 1.1.0
* Every Buff can now be toggled